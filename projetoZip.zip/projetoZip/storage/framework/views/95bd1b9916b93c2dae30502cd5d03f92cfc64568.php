<body style = "background-color: #669900">
	<div style = "background-color: white; padding: 1% 1%">
		<h3>A exclusão não funciona no momento</h3>
		<p>A exclusão de animais será possível depois do cadastro no banco de dados</p>
		<a href="<?php echo e(route('inicial')); ?>">Voltar</a>	
	</div>
</body>
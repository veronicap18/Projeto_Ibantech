<body style = "background-color: #669900">
	<div style = "background-color: white; padding: 1% 1%">
		<h3>A lista não imprime no momento</h3>
		<p>A lista de cadastros e manutenções aparecerá após o cadastro no banco de dados</p>

		<a href="<?php echo e(route('inicial')); ?>">Voltar</a>
	</div>
</body>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<ul>
		Carro. 
		<li><a href = "<?php echo e(route('home')); ?>">Voltar</a></li>
	</ul>

</body>
</html>>
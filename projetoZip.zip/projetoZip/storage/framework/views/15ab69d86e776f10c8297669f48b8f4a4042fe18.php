<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<ul>
		<!--<li><a href="/carro">Carro</a></li>-->
		<!--<li><a href="/cliente">Cliente</a></li>-->
		<li><a href = "<?php echo e(route('carro')); ?>">Carro</a></li>
		<li><a href = "<?php echo e(route('cliente')); ?>">Cliente</a></li>
		<li><a href = "<?php echo e(route('formulario')); ?>">Formulário</a></li>
		<li><a href="">Sair</a></li>
	</ul>
</body>
</html>
<!DOCTYPE html>
<html>
<head>
	<style>
		.entrada{
			margin-top: 10%;
			background-color: white;
			height: 110px;
			width: 25%;
			font-size: 12pt;
		}

		.sobre{
			margin-top: 4%;
			background-color: white;
			height: 105px;
			width: 45%;
			font-size: 12pt;
			padding: 1% 1%;
		}

		.ibantech{
			height: 20%;
			width: 100%;
			font-family: uroob;
			background-color: white;
			padding-top: 1%;
		}



	</style>
</head>
	<body style="background-color: #669900">
		<div class = "ibantech">
			<center><h1><u>Ibantech</u></h1></center>
		</div>
		<center>
			<div class="entrada">
				<form action = "<?php echo e(route('inicial')); ?>">
					<label>
						<center>Email: <input type="email" name="usuario" style = "margin-top: 7%"><br></center>
						<center>Senha: <input type="password" name="senha"><br></center><br>
						<input type = "submit"/>
					</label>
				</form>
				
			</div>
			<br><a href="<?php echo e(route('formulario')); ?>" style = "text-decoration: none; color: black">Cadastre-se</a>
		<div class = "sobre">	
			<p> O ibantech tem como objetivo o registro de informações a respeito dos animais confiscados pelo Instituto Brasileiro do Meio Ambiente e dos Recursos Naturais Renováveis (IBAMA). É possível registrar um animal novo e sua respectiva quantidade dentro do departamento, e ainda atualizar a sua manutenção, que inclui, abastecimento de água e comida, limpeza local e vacinação. Também pode-se excluir registros caso seja necessário. </p>
		</div>
		</center>	
	</body>
</html>
<!DOCTYPE html>
<html>
<head>
	<title> Formulário </title>
</head>
<body>
	<form action = "" method = "post">
		Nome: <input type = "text" name  = "nome"> <br/>
		Idade: <input type = "number" name  = "nome"> <br/>
		<input type = "submit" value = "submit">
	</form>

	<ul>
		<li><a href = "<?php echo e(route('home')); ?>">Voltar</a></li>
	</ul>

</body>
</html>>
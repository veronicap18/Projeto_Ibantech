<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/index', 'projeto1Controller@index')->name('index');

Route::get('/', 'projeto1Controller@home')->name('home');

Route::get('/formulario', 'projeto1Controller@formulario')->name('formulario');

Route::get('/inicial', 'projeto1Controller@inicial')->name('inicial');

Route::get('/cadastro', 'projeto1Controller@cadastro')->name('cadastro');

Route::get('/atualizaçao', 'projeto1Controller@atualizaçao')->name('atualizaçao');

Route::get('/excluir', 'projeto1Controller@excluir')->name('excluir');

Route::get('/listar', 'projeto1Controller@listar')->name('listar');
?>
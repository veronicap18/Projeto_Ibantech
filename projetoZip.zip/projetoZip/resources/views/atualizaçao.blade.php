<head>
	<script>
		function myFunction(){
			var button = alert("Histórico de manutenção atualizado");
		}

	</script>


</head>
<body style="background-color: #669900">
	<form>
		<div style = "background-color: white; padding: 1% 1%">
			<h2> Atualizar o histórico de manutenção </h2>
			Última limpeza: <input type = "date" name = "ult_limpeza"/><br>
			Próxima limpeza: <input type = "date" name = "prox_limpeza"/><br>
			Próxima vacina: <input type = "date" name = "prox_vacina"/><br>
			Última alimentação: <input type = "date" name = "ult_alimentacao"/><br>
			Próxima alimentação: <input type = "date" name = "prox_alimentacao"/><br>

			<br><button id = "botao_atualizacao" onclick="myFunction()">Atualizar</button>
		</div>
		<br>
		<a href="{{route('inicial')}}" style = "text-decoration: none; color: black">Voltar</a>		
</body>

<!DOCTYPE html>
<html>
<head>
	<title> Inicial</title>
	<style>
		.dropdown {
			color: black;
    		position: relative;
    		display: inline-block;
    		text-decoration: none;
    		list-style: none;
		}

		.dropdown-content {
		    display: none;
		    position: absolute;
		    min-width: 160px;
		    text-decoration: none;
		    list-style: none;
		}

		.dropdown:hover	.dropdown-content {
    		display: block;
		}	

	</style>
</head>
<body style="background-color: #669900">
	<div style="background-color: white; padding: 1% 1%">
		<form action = "{{route('home')}}">
			<ul><a href="{{route('listar')}}" class="dropdown"><b> Listar </b></a></ul>

			<ul class="dropdown"><p><b>Configurar</b></p>
				<li>
					<a href = "{{route('cadastro')}}" class="dropdown-content">Cadastrar animal</a>
				</li><br>
				<li>
					<a href = "{{route('atualizaçao')}}" class="dropdown-content">Atualizar manutenção</a>
				</li><br>
				<li>
					<a href = "{{route('excluir')}}" class="dropdown-content">Excluir</a>
				</li>
			</ul><br><br>

			<input type = "submit"/ value = "Sair"/>
		</form>
	</div>
</body>
</html>
<head>
	<script>
		function myFunction(){
			var button = alert("Animal cadastrado com sucesso!");
		}

	</script>


</head>
<body style="background-color: #669900">
	<div style = "background-color: white; padding: 1% 1%">
		<h2> Cadastro de animais </h2>
		Nome do animal: <input type = "text" name = "nome_animal"/><br>
		Espécie do animal: <input type = "text" name = "esp_animal"/><br>
		Unidade(s): <input type = "number" name = "unidades"/><br>
		Núm. do setor: <input type = "number" name = "num_setor"/><br>

		<button id = "botao_cadastro" onclick="myFunction()">Cadastrar</button>
	</div>
	<br>
	<a href="{{route('inicial')}}" style = "text-decoration: none; color: black">Voltar</a>	
</body>
<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class inicial extends Model
{
    //
}

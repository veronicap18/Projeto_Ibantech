<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class manutencao extends Model
{
    //
}

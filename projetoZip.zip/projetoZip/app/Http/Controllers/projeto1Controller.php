<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class projeto1Controller extends Controller
{

	public function index()
	{
	    return view ('index');
	}

	public function home()
	{
	    return view('home');
	}

	public function formulario()
	{
	    return view('formulario');
	}

	public function inicial()
	{
	    return view('inicial');
	}

	public function cadastro()
	{
	    return view('cadastro');
	}

	public function atualizaçao()
	{
	    return view('atualizaçao');
	}

	public function excluir()
	{
	    return view('excluir');
	}

	public function listar()
	{
	    return view('listar');
	}
}

